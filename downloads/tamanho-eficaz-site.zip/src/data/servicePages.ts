export const servicePages = [
  {
    "slug": "soldadura",
    "title": "Soldadura",
    "image": "/images/services/soldadura.jpg",
    "intro": "A nossa empresa é especializada em serviços de soldadura na área de metalomecânica, oferecendo soluções de alta qualidade e precisão para as necessidades industriais e comerciais dos nossos clientes. Com uma equipa de soldadores altamente qualificados e experientes, garantimos um serviço eficiente, seguro e conforme com as normas e padrões exigidos no mercado.",
    "items": [
      [
        "Soldadura MIG/MAG",
        "Ideal para soldadura de metais ferrosos e não ferrosos, proporcionando uma fusão forte e duradoura."
      ],
      [
        "Soldadura TIG",
        "Adequada para soldaduras de alta precisão em materiais como aço inoxidável, alumínio e outros metais não ferrosos."
      ],
      [
        "Soldadura Eléctrica",
        "Utilizada principalmente em construção civil e na reparação de estruturas metálicas."
      ],
      [
        "Soldadura por Ponto",
        "Excelente para união de chapas metálicas finas, comum em indústrias automotivas e de eletrodomésticos."
      ],
      [
        "Soldadura de Estruturas Metálicas",
        "Fabricação e reparação de estruturas metálicas para construção civil, infraestruturas e projetos industriais."
      ]
    ],
    "why": [
      [
        "Qualidade e Precisão",
        "Utilizamos equipamentos de última geração e técnicas avançadas para garantir acabamentos de alta qualidade."
      ],
      [
        "Experiência e Profissionalismo",
        "A nossa equipa é composta por soldadores certificados com vasta experiência no setor."
      ],
      [
        "Prazos Cumpridos",
        "Comprometemo-nos a entregar os projetos dentro dos prazos estipulados, sem comprometer a qualidade."
      ],
      [
        "Segurança",
        "Priorizamos a segurança dos nossos colaboradores e clientes, cumprindo todas as normas de segurança vigentes."
      ],
      [
        "Atendimento Personalizado",
        "Oferecemos soluções adaptadas às necessidades específicas de cada cliente, assegurando a sua satisfação total."
      ]
    ]
  },
  {
    "slug": "serralharia",
    "title": "Serralharia",
    "image": "/images/services/serralharia.jpg",
    "intro": "A nossa empresa é líder em serviços de serralharia na área de metalomecânica, oferecendo soluções personalizadas e de alta qualidade para atender às diversas necessidades dos nossos clientes. Contamos com uma equipa de serralheiros altamente qualificados e experientes, prontos para realizar projetos de pequena, média e grande escala com excelência e profissionalismo.",
    "items": [
      [
        "Fabricação e Montagem de Estruturas Metálicas",
        "Desenvolvemos e instalamos estruturas metálicas robustas e seguras, ideais para construção civil, industriais e comerciais."
      ],
      [
        "Coberturas Metálicas",
        "Desenvolvemos coberturas metálicas resistentes e duradouras, ideais para proteções externas em diversos ambientes."
      ],
      [
        "Manutenção e Reparação",
        "Oferecemos serviços de manutenção e reparação de estruturas metálicas, prolongando a vida útil e garantindo a segurança das instalações."
      ]
    ],
    "why": [
      [
        "Qualidade Superior",
        "Utilizamos materiais de alta qualidade e técnicas avançadas para garantir a durabilidade e resistência das nossas obras."
      ],
      [
        "Experiência Comprovada",
        "A nossa equipa possui vasta experiência no setor, assegurando a execução precisa e eficiente de cada projeto."
      ],
      [
        "Cumprimento de Prazos",
        "Comprometemo-nos com a entrega pontual dos projetos, respeitando os prazos acordados sem comprometer a qualidade."
      ],
      [
        "Segurança",
        "Priorizamos a segurança em todas as etapas do trabalho, cumprindo rigorosamente as normas de segurança estabelecidas."
      ],
      [
        "Atendimento Personalizado",
        "Oferecemos soluções feitas à medida das necessidades específicas de cada cliente, garantindo a sua plena satisfação."
      ]
    ]
  },
  {
    "slug": "serralharia-mecanica",
    "title": "Serralharia Mecânica",
    "image": "/images/services/serralharia-mecanica.jpg",
    "intro": "Na nossa empresa, somos especialistas em serviços de serralharia mecânica na área de metalomecânica, oferecendo soluções inovadoras e de alta qualidade para os mais diversos setores industriais. Com uma equipa de serralheiros mecânicos altamente qualificados e equipados com tecnologia de ponta, garantimos a execução precisa e eficiente de cada projeto.",
    "items": [
      [
        "Fabricação de Peças Sob Encomenda",
        "Produzimos peças e componentes metálicos personalizados, utilizando técnicas avançadas de corte, dobragem e soldadura."
      ],
      [
        "Montagem de Equipamentos Industriais",
        "Realizamos a montagem de equipamentos industriais complexos, assegurando a precisão e qualidade em cada etapa."
      ],
      [
        "Manutenção e Reparação de Estruturas Metálicas",
        "Serviços de manutenção e reparação destinados a garantir durabilidade, segurança e eficiência operacional."
      ],
      [
        "Construção de Estruturas Metálicas Personalizadas",
        "Estruturas metálicas sob medida para suporte de máquinas, estruturas de apoio e outros projetos industriais específicos."
      ],
      [
        "Serviços de Usinagem e Torneamento",
        "Serviços de usinagem e torneamento de precisão, com atenção à qualidade dimensional e acabamento."
      ]
    ],
    "why": [
      [
        "Tecnologia de Ponta",
        "Utilizamos equipamentos modernos e tecnologias avançadas para assegurar precisão e qualidade."
      ],
      [
        "Equipa Especializada",
        "Profissionais experientes e certificados, com experiência em serralharia mecânica e metalomecânica."
      ],
      [
        "Compromisso com Prazos",
        "Cumprimos os prazos acordados sem comprometer a qualidade."
      ],
      [
        "Segurança e Conformidade",
        "Seguimos práticas de segurança e normas e regulamentos aplicáveis."
      ],
      [
        "Soluções Personalizadas",
        "Desenvolvemos soluções para as necessidades específicas de cada cliente."
      ]
    ]
  },
  {
    "slug": "eletricidade",
    "title": "Eletricidade",
    "image": "/images/services/eletricidade.jpg",
    "intro": "A nossa empresa é especializada em serviços de eletricidade na área de metalomecânica, oferecendo soluções integradas e de alta qualidade para projetos industriais e comerciais. Contamos com uma equipa de eletricistas altamente qualificados e experientes, prontos para atender às necessidades específicas dos nossos clientes com eficiência e profissionalismo.",
    "items": [
      [
        "Instalação e Manutenção de Sistemas Elétricos Industriais",
        "Instalação e manutenção de sistemas elétricos em instalações industriais, visando uma operação segura e eficiente."
      ],
      [
        "Automação Industrial",
        "Soluções de automação industrial, incluindo programação e instalação de controladores lógicos programáveis (PLC) e sistemas de controlo de processos."
      ],
      [
        "Quadros Elétricos",
        "Projeto, montagem e instalação de quadros elétricos personalizados."
      ],
      [
        "Iluminação Industrial",
        "Instalação e manutenção de sistemas de iluminação industrial, visando eficiência energética e melhores condições de trabalho."
      ],
      [
        "Segurança Elétrica",
        "Auditorias e inspeções de segurança elétrica, identificação e correção de possíveis riscos."
      ]
    ],
    "why": [
      [
        "Qualidade e Precisão",
        "Materiais de qualidade e técnicas destinadas à fiabilidade e durabilidade dos sistemas."
      ],
      [
        "Equipa Especializada",
        "Eletricistas certificados e com experiência no setor da metalomecânica."
      ],
      [
        "Cumprimento de Prazos",
        "Compromisso com os prazos acordados."
      ],
      [
        "Segurança",
        "Cumprimento das normas e regulamentos de segurança."
      ],
      [
        "Soluções Personalizadas",
        "Soluções adaptadas às necessidades específicas de cada cliente."
      ]
    ]
  },
  {
    "slug": "tubistas",
    "title": "Tubistas",
    "image": "/images/services/tubistas.jpg",
    "intro": "A nossa empresa é especialista em serviços de tubagem na área de metalomecânica, oferecendo soluções completas e de alta qualidade para projetos industriais e comerciais. Contamos com uma equipa de tubistas altamente qualificados e experientes, prontos para atender às necessidades específicas dos nossos clientes com eficiência e profissionalismo.",
    "items": [
      [
        "Instalação de Sistemas de Tubagem",
        "Instalação de sistemas de tubagem para transporte de fluidos e gases em instalações industriais."
      ],
      [
        "Manutenção e Reparação de Tubagens",
        "Manutenção e reparação destinadas a assegurar a durabilidade e a operação contínua dos sistemas."
      ],
      [
        "Montagem de Tubagem Industrial",
        "Montagem de tubagem em fábricas, refinarias, centrais elétricas e outras instalações industriais."
      ],
      [
        "Soldadura de Tubagem",
        "Soldadura especializada em aço carbono, aço inoxidável, cobre e outros materiais."
      ],
      [
        "Inspeção e Testes de Tubagem",
        "Inspeções e testes dos sistemas de tubagem para verificação de segurança e qualidade."
      ]
    ],
    "why": [
      [
        "Qualidade e Precisão",
        "Materiais e técnicas orientados para a durabilidade e eficiência."
      ],
      [
        "Equipa Especializada",
        "Tubistas certificados e com experiência no setor."
      ],
      [
        "Cumprimento de Prazos",
        "Compromisso com os prazos acordados."
      ],
      [
        "Segurança",
        "Prioridade à segurança em todas as etapas do trabalho."
      ],
      [
        "Soluções Personalizadas",
        "Soluções adaptadas às necessidades específicas de cada cliente."
      ]
    ]
  },
  {
    "slug": "operadores-de-grua",
    "title": "Operadores de Grua",
    "image": "/images/services/operadores-de-grua.jpg",
    "intro": "A nossa empresa oferece serviços especializados de operadores de grua na área de metalomecânica, garantindo a movimentação segura e eficiente de cargas pesadas e materiais em projetos industriais e comerciais. Contamos com uma equipa de operadores de grua altamente qualificados e experientes.",
    "items": [
      [
        "Operação de Gruas de Torre e Móveis",
        "Operação de gruas de torre e gruas móveis para diferentes tipos de projetos e condições de trabalho."
      ],
      [
        "Movimentação de Cargas Pesadas",
        "Movimentação de cargas pesadas e volumosas com atenção à integridade dos materiais e à segurança."
      ],
      [
        "Montagem e Desmontagem de Gruas",
        "Montagem e desmontagem de gruas em estaleiros de obras."
      ],
      [
        "Planeamento e Coordenação de Operações",
        "Planeamento e coordenação das operações de movimentação de cargas."
      ],
      [
        "Manutenção Preventiva e Corretiva",
        "Manutenção preventiva e corretiva das gruas, visando operacionalidade e segurança."
      ]
    ],
    "why": [
      [
        "Profissionalismo e Experiência",
        "Operadores de grua certificados e com experiência no setor."
      ],
      [
        "Segurança Prioritária",
        "Cumprimento das normas de segurança."
      ],
      [
        "Equipamentos Modernos",
        "Utilização de equipamentos adequados às operações."
      ],
      [
        "Cumprimento de Prazos",
        "Compromisso com a conclusão das operações dentro do tempo previsto."
      ],
      [
        "Atendimento Personalizado",
        "Soluções adaptadas às necessidades específicas de cada cliente."
      ]
    ]
  }
] as const;

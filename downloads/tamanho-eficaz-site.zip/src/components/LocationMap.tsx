import {MapPin, ArrowUpRight} from "lucide-react";

const address = "R. Mercado 26, 3020-863 Souselas, Portugal";
const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;

export default function LocationMap() {
  return <a className="refLocationMap" href={googleMapsUrl} target="_blank" rel="noreferrer" aria-label="Abrir localização da Tamanho Eficaz no Google Maps">
    <img className="refLocationPoster" src="/images/reference/coimbra-map.svg" alt="Mapa de Portugal e da Europa com Coimbra assinalada"/>
    <span className="refMapLink"><MapPin size={18} aria-hidden="true"/>Abrir no Google Maps<ArrowUpRight size={16} aria-hidden="true"/></span>
  </a>;
}

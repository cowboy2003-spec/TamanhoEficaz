"use client";

import Link from "next/link";
import {usePathname} from "next/navigation";
import {Header, Footer} from "./Layout";
import LanguageSwitcher from "./LanguageSwitcher";
import MobileMenu from "./MobileMenu";

const navigation = [
  ["/empresa", "Empresa"], ["/servicos", "Serviços"],
  ["/projetos", "Projetos"], ["/internacional", "Internacional"],
  ["/noticias", "Notícias"], ["/trabalhe-connosco", "Carreiras"],
  ["/contactos", "Contactos"],
] as const;

export default function ReferenceFrame({children}: {children: React.ReactNode}) {
  const pathname = usePathname();
  const reference = navigation.some(([href]) => pathname === href);
  // Preserve the approved ZIP's Home, including its shared header and footer.
  if (!reference) return <><Header/>{children}<Footer showCta={pathname!=="/"} linkDeveloper={pathname==="/"}/></>;
  return <div className="referenceSite">
    <header className="refHeader"><div className="refNav">
      <Link href="/" className="refLogo" aria-label="Tamanho Eficaz — Home">
        <img src="/images/brand/tamanho-eficaz-logo.png" alt="Tamanho Eficaz"/>
      </Link>
      <nav className="refMenu" aria-label="Navegação principal">
        {navigation.map(([href,label]) => <Link key={href} href={href} aria-current={pathname === href ? "page" : undefined}>{label}</Link>)}
      </nav>
      <div className="refDesktopLanguage"><LanguageSwitcher compact/></div>
      <MobileMenu/>
    </div></header>
    {children}<Footer/>
  </div>;
}
